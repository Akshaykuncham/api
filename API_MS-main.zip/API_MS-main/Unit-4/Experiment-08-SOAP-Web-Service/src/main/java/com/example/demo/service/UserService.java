package com.example.demo.service;

import org.springframework.stereotype.Service;

@Service
public class UserService {
    public String getUserName(long id) {
        return "User-" + id;
    }
}
