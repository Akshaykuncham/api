package com.example.demo.model;

import jakarta.persistence.*;

@Entity
public class User {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String email;

    public User() {}
    public User(String name, String email) { this.name=name; this.email=email; }
    public Long getId(){return id;} public String getName(){return name;} public String getEmail(){return email;}
    public void setName(String n){name=n;} public void setEmail(String e){email=e;}
}
